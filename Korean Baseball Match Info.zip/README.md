
  # Korean Baseball Match Info

  This is a code bundle for Korean Baseball Match Info. The original project is available at https://www.figma.com/design/gcT8nTEMGm6lPOYXVZgh70/Korean-Baseball-Match-Info.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  